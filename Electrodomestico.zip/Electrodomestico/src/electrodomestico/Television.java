package electrodomestico;

public class Television extends Electrodomestico{
    
    public static int Resolucion = 20;
    public boolean SintonizadorTDT = false;
    double PrecioFinal;
    
    public Television(double PrecioBase, String Color, char ConsumoEnergetico, double Peso, boolean SintonizadorTDT, int Resolucion) {
        super(PrecioBase, Color, ConsumoEnergetico, Peso);
        this.Resolucion = Resolucion;
        this.SintonizadorTDT = SintonizadorTDT;
    }
    
    public Television (double PrecioBase, double Peso){
        super (PrecioBase, Peso);
    }
    
    public int getResolucion (){
        return Resolucion;
    }
    
    public boolean getSintonizadorTDT (){
        return SintonizadorTDT;
    }
    
    public void PrecioFinal(){
        if (Resolucion > 40) {           
           PrecioFinal = PrecioBase*.70;
        }
        
        if (SintonizadorTDT = true){
            PrecioFinal = PrecioBase + 500;
        }
    }       
}